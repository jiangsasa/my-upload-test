import pandas as pd
from py.arima_jumin import predict_jumin
from py.arima_nongye import predict_nongye
from py.lstm_dailigoudian import predict_dailigoudian
from py.lstm_shichanghua import predict_shichanghua
import warnings
import sys
import tensorflow as tf

warnings.filterwarnings('ignore')
# 设置TensorFlow日志记录级别
tf.get_logger().setLevel('ERROR')

print("-------------------------------开始加载数据-------------------------------")
# 加载数据
df_jumin = pd.read_csv('data/居民.csv')
df_shichanghua = pd.read_csv('data/市场化.csv')
df_nongye = pd.read_csv('data/农业.csv')
df_dailigoudian = pd.read_csv('data/代理购电.csv')

last_date1 = pd.to_datetime(df_jumin['date'].iloc[-1])
last_date2 = pd.to_datetime(df_shichanghua['date'].iloc[-1])
last_date3 = pd.to_datetime(df_nongye['date'].iloc[-1])
last_date4 = pd.to_datetime(df_dailigoudian['date'].iloc[-1])
if (last_date1 == last_date2 and last_date1 == last_date3 and last_date1 == last_date4):
    predict_month = last_date1 + pd.DateOffset(months=1)
    predict_month_str = predict_month.strftime('%Y年%m月')
    print(f'即将预测{predict_month_str}用电量')
else:
    print("输入数据月份不统一！")
    sys.exit() # 结束程序
print("-------------------------------加载数据完毕-------------------------------")

print("-------------------------------开始进行预测-------------------------------")
# 预测
results = []

targets = ['客户服务中心', '开发区供电中心', '东营港供电中心', '黄三角农高区供电中心',
          '广饶县供电公司', '利津县供电公司','垦利区供电公司', '河口区供电公司', '东营区供电公司']

for target in targets:
    pred_jumin = predict_jumin(df_jumin, target)
    print(target, "居民预测结果：", pred_jumin)
    pred_nongye = predict_nongye(df_nongye, target)
    print(target, "农业预测结果：", pred_nongye)
    pred_dailigoudian = predict_dailigoudian(df_dailigoudian, target)
    print(target, "代理购电预测结果：", pred_dailigoudian)
    pred_shichanghua = predict_shichanghua(df_shichanghua, target)
    print(target, "市场化预测结果：", pred_shichanghua)
    total = pred_jumin + pred_nongye + pred_dailigoudian + pred_shichanghua
    results.append({
        '地市': target,
        '居民': pred_jumin,
        '农业': pred_nongye,
        '代理购电': pred_dailigoudian,
        '直接参与市场用户电量': pred_shichanghua,
        '总电量': total
    })

# 将结果转换为 DataFrame
results_df = pd.DataFrame(results)
# 计算各分类的总和
total_row = {
    '地市': '合计',
    '居民': results_df['居民'].sum(),
    '农业': results_df['农业'].sum(),
    '代理购电': results_df['代理购电'].sum(),
    '直接参与市场用户电量': results_df['直接参与市场用户电量'].sum(),
    '总电量': results_df['总电量'].sum()
}
total_df = pd.DataFrame([total_row])
results_df = pd.concat([results_df, total_df], ignore_index=True)

# 保存到 Excel 文件
results_df.to_excel(f'{predict_month_str}预测结果.xlsx', index=False)
print("\n")
print(f"----------------------预测结果已经生成，请按任意键退出并查看！----------------------")
input("按回车键退出并查看结果...")
