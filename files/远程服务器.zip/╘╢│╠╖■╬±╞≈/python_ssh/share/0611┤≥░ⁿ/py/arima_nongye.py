import pandas as pd
import numpy as np
import pmdarima as pm
import warnings

# def predict_nongye(data, target):
#     warnings.filterwarnings('ignore')
#     train = data[target].values
#     train = train[train > 0]
#     # 如果train为空，直接返回0
#     if len(train) == 0:
#         return 0
#     # 对数据进行对数变换
#     train = np.log(train + 1)

#     if target == '开发区供电中心':
#         model = pm.arima.ARIMA(order=(0, 1, 0), seasonal_order=(0, 0, 0, 12))
#     elif target == '东营港供电中心':
#         model = pm.arima.ARIMA(order=(1, 1, 1), seasonal_order=(1, 0, 0, 12))
#     elif target == '黄三角农高区供电中心':
#         model = pm.arima.ARIMA(order=(0, 1, 0), seasonal_order=(0, 0, 0, 12))
#     elif target == '广饶县供电公司':
#         model = pm.arima.ARIMA(order=(2, 1, 1), seasonal_order=(1, 0, 1, 12))
#     elif target == '利津县供电公司':
#         model = pm.arima.ARIMA(order=(1, 1, 1), seasonal_order=(1, 0, 2, 12))
#     elif target == '垦利区供电公司':
#         model = pm.arima.ARIMA(order=(0, 1, 0), seasonal_order=(0, 0, 1, 12))
#     elif target == '河口区供电公司':
#         model = pm.arima.ARIMA(order=(1, 1, 1), seasonal_order=(2, 0, 0, 12))
#     elif target == '东营区供电公司':
#         model = pm.arima.ARIMA(order=(1, 1, 2), seasonal_order=(1, 0, 0, 12))
#     else:
#         model = pm.arima.ARIMA(order=(2, 1, 0), seasonal_order=(1, 0, 1, 12)) # 默认模型
#     model_fit = model.fit(train)
#     y_pred = model_fit.predict(n_periods=1)[0]

#     # 对预测值进行逆对数变换
#     y_pred = np.exp(y_pred) - 1
#     return y_pred

def predict_nongye(data, target):
    warnings.filterwarnings('ignore')
    train = data[target].values
    if (train[-1] == 0):  # 如果上个月值为0，直接返回0
        return 0
    train = train[train > 0]
    if len(train) == 0:  # 如果train为空，直接返回0
        return 0
    # 对数据进行对数变换
    train = np.log(train + 1)

    if len(train) < 24 and target == '黄三角农高区供电中心':  # 数据较少，数据量大于24条后可用网格搜索
        model = pm.arima.ARIMA(order=(0, 1, 0), seasonal_order=(0, 0, 0, 12))
    else:
        # 使用auto_arima进行网格搜索，包含季节性参数
        model = pm.auto_arima(
            train,
            start_p=0, max_p=10,
            start_q=0, max_q=10,
            d=None,                      # 自动选择d
            seasonal=True,               # 启用季节性
            m=12,                        # 季节性周期，一年有12个月
            start_P=0, max_P=10,
            start_Q=0, max_Q=10,
            D=None,                      # 自动选择D
            # trace=True,                  # 打印网格搜索过程
            error_action='ignore',       # 忽略错误继续进行
            suppress_warnings=True,      # 忽略警告
            stepwise=True                # 使用逐步搜索
        )
    
    # 拟合模型
    model_fit = model.fit(train)
    
    # 打印最优参数
    print(f'最佳模型参数: {model.order}(p,d,q){model.seasonal_order}(P,D,Q,m) 训练数据条数：{len(train)}')

    y_pred = model_fit.predict(n_periods=1)[0]

    # 对预测值进行逆对数变换
    y_pred = np.exp(y_pred) - 1
    return y_pred

# data = pd.read_csv('0602打包/农业全数据-202405.csv')
# target = '开发区供电中心'
# y_pred= predict_nongye(data, target)
# print(y_pred)