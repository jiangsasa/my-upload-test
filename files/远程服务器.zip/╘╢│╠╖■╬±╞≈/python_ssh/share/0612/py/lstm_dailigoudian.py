from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout
import numpy as np
import pandas as pd
import os
import random
import tensorflow as tf
from keras import backend as K

os.environ['PYTHONHASHSEED'] = '0'
np.random.seed(42)
random.seed(42)
tf.random.set_seed(42)

def reset_seeds():
    np.random.seed(42)
    tf.random.set_seed(42)
    random.seed(42)

def reset_keras_session():
    K.clear_session()
    tf.compat.v1.reset_default_graph()
    reset_seeds()

def prepare_data(train_data, target, feature_columns, n_steps=4):
    df = pd.DataFrame(train_data)
    df['增长率'] = df[target].pct_change().fillna(0)  # 填充NaN，首次增长率为0
    df['增长率'] = df['增长率'].replace([np.inf, -np.inf], 0)
    
    # 归一化
    scaler_features = MinMaxScaler()
    scaler_target = MinMaxScaler()
    
    feature_data = df[feature_columns + ['增长率']]
    target_data = df[[target]]
    
    df_scaled_features = pd.DataFrame(scaler_features.fit_transform(feature_data), columns=feature_data.columns)
    df_scaled_target = pd.DataFrame(scaler_target.fit_transform(target_data), columns=target_data.columns)
    
    df_scaled = pd.concat([df_scaled_features, df_scaled_target], axis=1)
    
    # 准备训练数据
    X_train, y_train = [], []
    for i in range(n_steps, len(df_scaled)):
        features = []
        power = df_scaled[target].iloc[i - 1]  # 前一个月的用电量
        features.append(power)
        growth_rates = df_scaled['增长率'].iloc[i - n_steps:i].values  # 前n_steps个增长率
        features.extend(growth_rates)
        
        for column in feature_columns:
            if column in df_scaled.columns:
                values = df_scaled[column].iloc[i - n_steps:i].values
                features.extend(values)
        
        X_train.append(features)
        y_train.append(df_scaled[target].iloc[i])  # 用电量

    # 预测输入数据
    features = []
    power = df_scaled[target].iloc[-1]  # 最后一个月的用电量
    features.append(power)
    growth_rates = df_scaled['增长率'].iloc[-n_steps:].values  # 倒数n_steps个月的增长率
    features.extend(growth_rates)
    
    for column in feature_columns:
        if column in df_scaled.columns:
            values = df_scaled[column].iloc[-n_steps:].values
            features.extend(values)
    
    X_pred = []
    X_pred.append(features)

    X_train, y_train = np.array(X_train), np.array(y_train)
    X_pred = np.array(X_pred)

    # 调整形状以适应LSTM输入要求
    X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
    X_pred = X_pred.reshape((X_pred.shape[0], X_pred.shape[1], 1))

    return X_train, y_train, X_pred, scaler_target

def build_model(input_shape):
    reset_keras_session()
    model = Sequential()
    model.add(LSTM(100, activation='relu', input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mae')
    return model

def new_lstm(train_data, target, feature_columns):
    n_steps = 4
    X_train, y_train, X_pred, scaler_target = prepare_data(train_data, target, feature_columns, n_steps=n_steps)

    input_shape=(X_train.shape[1], 1)
    # 构建LSTM模型
    model = build_model(input_shape)
    
    # 训练模型
    model.fit(X_train, y_train, epochs=100, batch_size=4, verbose=0)
    
    # 预测
    y_pred = model.predict(X_pred, verbose=0)
    
    # 逆归一化预测结果
    y_pred_inv = scaler_target.inverse_transform(y_pred)  # 逆归一化
    return y_pred_inv[0][0]

def predict_dailigoudian(data, target):
    feature_columns_more = ['下月节假日数量', '本月节假日数量', '本月平均高温', '本月平均低温']
    train_data = data[[target] + feature_columns_more]
    y_pred= new_lstm(train_data, target, feature_columns_more)
    return y_pred

# data = pd.read_csv('0612/data/代理购电.csv')
# target = '开发区供电中心'
# y_pred= predict_dailigoudian(data, target)
# print(y_pred)